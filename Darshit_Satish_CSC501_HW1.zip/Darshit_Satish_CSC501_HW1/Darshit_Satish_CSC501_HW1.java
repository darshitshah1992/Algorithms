import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Darshit and Satish
 */
public class Darshit_Satish_CSC501_HW1 {
    
    static int numberOfPersons=-1;
    static String[] men=null;
    static String[] women=null;
    static String[][] menPrefrences=null;
    static String[][] womenPrefrences=null;
    static int engagedMen=0;
    static String[] menPartnered=null;
    static int[] isMenEngaged=null;
    static HashMap hashMap = new HashMap();
    static String man="M";
    static String woman="W";

    public static void main(String[] args) {
 
        System.out.println("Please enter number of men or women: ");
        Scanner scanner= new Scanner(System.in);
        numberOfPersons=scanner.nextInt();
        
        men = new String[numberOfPersons];
        women = new String[numberOfPersons];
        
        System.out.println("************************************************************");
        
        menPrefrences=prepareRandomPreferences(true,numberOfPersons);
        System.out.println("Men preferences: ");
        
        for(int i=0;i<menPrefrences.length;i++)
            {
                men[i]=man+(i+1);
                System.out.print(men[i]+": ");
                for(int j=0;j<menPrefrences.length;j++)
                {
                    System.out.print(menPrefrences[i][j]+" ");
                }
                System.out.println("");
            }
        
        System.out.println("");
        womenPrefrences=prepareRandomPreferences(false,numberOfPersons);
        
        System.out.println("Women preferences: ");
        for(int i=0;i<womenPrefrences.length;i++)
            {
                women[i]=woman+(i+1);
                System.out.print(women[i]+": ");
                for(int j=0;j<womenPrefrences.length;j++)
                {
                    System.out.print(womenPrefrences[i][j]+" ");
                }
                System.out.println("");
            }
        
        System.out.println("************************************************************");
        
        ArrayList<Integer> usedNumberForIterationLst= new ArrayList<Integer>();
        Random random = new Random();
        
        for(int i=0;i<numberOfPersons;i++)
        {
            int number=random.nextInt(numberOfPersons);
            while(notUniqueNumber(number,usedNumberForIterationLst))
                {                                               
                    number = random.nextInt(numberOfPersons);
                }
            usedNumberForIterationLst.add(number);
            engagedMen=0;
            isMenEngaged = new int[numberOfPersons];
            menPartnered = new String[numberOfPersons];
            executeGSAlgorithm(number,usedNumberForIterationLst);
        }
        
        Iterator iterator = hashMap.entrySet().iterator();
        while (iterator.hasNext()) 
            {
                Map.Entry mapEntry = (Map.Entry) iterator.next();
                System.out.println("Count of the number of iteration " + mapEntry.getKey() + ": " + mapEntry.getValue());
            }
    }
    
    public static String[][] prepareRandomPreferences(boolean men, int numberOfPerson)
    {
        String[][] preferences = new String[numberOfPerson][numberOfPerson];
        Random random = new Random();
         
        if(men)
        {
            for(int i=0;i<numberOfPerson;i++)
            {
                ArrayList<Integer> usedNumbers=new ArrayList<Integer>();
                
                int number=random.nextInt(numberOfPerson);
                number++;
                
                for(int j=0;j<numberOfPerson;j++)
                {
                    while(notUniqueNumber(number,usedNumbers))
                    {                                               
                        number = random.nextInt(numberOfPerson);
                        number++;
                    }
                    usedNumbers.add(number);
                    preferences[i][j]= woman+String.valueOf(number);
                }
            }
        }
        else
        {
            for(int i=0;i<numberOfPerson;i++)
            {
                ArrayList<Integer> usedNumbers=new ArrayList<Integer>();
                
                int number=random.nextInt(numberOfPerson);
                number++;
                
                for(int j=0;j<numberOfPerson;j++)
                {
                    while(notUniqueNumber(number,usedNumbers))
                    {                                               
                        number = random.nextInt(numberOfPerson);
                        number++;
                    }
                    usedNumbers.add(number);
                    preferences[i][j]= man+String.valueOf(number);
                }
            }
        }
        return preferences;
    }
    
    public static boolean notUniqueNumber(int number, ArrayList<Integer> usedNumbers)
    {
        boolean flag=false;
        
        if(usedNumbers!=null)
        {
            for(int i=0;i<usedNumbers.size();i++)
            {
                if(usedNumbers.get(i)==number)
                {
                    flag=true;
                    break;
                }
            }
        }
        return flag;
    }
    
    public static int getPrefrenceIndex(String currentProposal, boolean isWomen)
    {
        int prefrence=-1;
        
        if(isWomen)
        {
            for(int i=0;i<women.length;i++)
            {
                if(currentProposal.equalsIgnoreCase(women[i]))
                {
                    prefrence=i;
                    break;
                }
            }
        }
        else
        {
            for(int i=0;i<men.length;i++)
            {
                if(currentProposal.equalsIgnoreCase(men[i]))
                {
                    prefrence=i;
                    break;
                }
            }   
        }
        
        return prefrence;
    }
    
    public static boolean isCurrentMenPrefrredMore(String engagedMen, String currentMen, int womenIndex)
    {
        boolean flag=false;
        
        for(int i=0;i<women.length;i++)
        {
            if(womenPrefrences[womenIndex][i].equalsIgnoreCase(currentMen))
            {
                flag=true;
                break;
            }
            else if(womenPrefrences[womenIndex][i].equalsIgnoreCase(engagedMen))
            {
                break;
            }
        }
        
        return flag;
    }
    
    public static ArrayList<Integer> executeGSAlgorithm(int startNumber, ArrayList<Integer> usedNumberForIterationLst)
    {
        long startTime=System.nanoTime();
        boolean isStartNumberUsed=false;
        int numberOfIteration=0;
        HashMap hashMapProposed = new HashMap();
        
        while(engagedMen < numberOfPersons)
        {
            if(!isStartNumberUsed)
            {               
                if(isMenEngaged[startNumber]==0)
                {  
                    System.out.println("First Proposing Man is "+man+ (startNumber+1));
                    isStartNumberUsed=true;
                }
            }
            else
            {
                for(int i=0;i<numberOfPersons;i++)
                {
                    if(isMenEngaged[i]==0)
                    {
                        startNumber=i;
                        System.out.println("Next Proposing Man is "+man+ (startNumber+1));
                        break;
                    }
                }
            }
                
            ArrayList<String> womenNumberList = null;
            for (int i = 0; (i < numberOfPersons) && isMenEngaged[startNumber]==0; i++)
            {   
                if(hashMapProposed!=null && hashMapProposed.containsKey(startNumber))
                {
                    womenNumberList = (ArrayList) hashMapProposed.get(startNumber);
                    if(womenNumberList.contains(menPrefrences[startNumber][i]))
                    {
                        continue;
                    }
                    else
                    {
                        womenNumberList.add(menPrefrences[startNumber][i]);
                    }
                }
                else
                {
                    womenNumberList = new ArrayList();
                    womenNumberList.add(menPrefrences[startNumber][i]);
                    hashMapProposed.put(startNumber, womenNumberList);
                }
                
                int index = getPrefrenceIndex(menPrefrences[startNumber][i],true);
                
                System.out.println(man+ (startNumber+1)+" proposing "+women[index]);
                numberOfIteration++;
                
                if (menPartnered[index] == null)
                {
                    menPartnered[index] = men[startNumber];
                    isMenEngaged[startNumber] = 1;
                    engagedMen++;
                }
                else
                {
                    String engagedMen = menPartnered[index];                   
                    if (isCurrentMenPrefrredMore(engagedMen, men[startNumber], index))
                    {   
                        System.out.println(engagedMen+" rejected by "+women[index]);
                        menPartnered[index] = men[startNumber];
                        isMenEngaged[startNumber] = 1;
                        isMenEngaged[getPrefrenceIndex(engagedMen,false)] = 0;
                    }
                    else
                    {
                        System.out.println(man+ (startNumber+1)+" rejected by "+women[index]);
                    }
                }
            }
        }
        
        if(hashMap!=null && hashMap.containsKey(numberOfIteration))
        {
            int count=Integer.valueOf(hashMap.get(numberOfIteration).toString());
            count++;
            
            hashMap.put(numberOfIteration,count);
        }
        else
        {
            hashMap.put(numberOfIteration,1);
        }
        
        System.out.println("Number of proposals are : "+numberOfIteration);
        System.out.println("Matched couples are : ");
        
        for (int i = 0; i < numberOfPersons; i++)
        {
            System.out.println(menPartnered[i] +" "+ women[i]);
        }
        
        long endTime=System.nanoTime();
        System.out.println("Time taken for matching is "+(endTime-startTime)+" nanoseconds");
        System.out.println("************************************************************");
        
        return usedNumberForIterationLst;
    }
}
