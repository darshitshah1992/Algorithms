***********************************************************************************************************************************************************************
How to Execute a Program:
1. Extract the folder present in the Zip Folder titled : Darshit_Satish_CSC501_HW1.zip 
2. Execute the .java file and it will prompt for "number of persons(n)" as input.
3. Enter number of persons for which Gale Shapley algorithm needs to be executed.
4. GS Algorithm will be executed and will display all required results including Men preferences, women preferences, 
   everytime who proposes first along with all proposals, number of proposals take for stable matching for respective man proposing first, 
   time taken for GS algorithm to execute each time, matched couples and also count of the number of iterations it takes after execution of GS algorithm n times. 

***********************************************************************************************************************************************************************

Detail analysis before implementation of algorithm:
A. Generate Random Number
B. Verify if the Random Number generated has already been used.
C. Post verification of Random Number, if it turns out to be not repeated then this number will be added into Arraylist which is created and titled as "UsedNumbers"
D. Post Verification of Random Number, if it turns out to be repeated number then it will enter into UniqueNumber method and 
   will continue till random number is generated
E. Once Preference List for Men is generated then we will print out Men Preference List
F. After completion of printing Men Preference List RandomPreference Process will continue for Women
G. same as Point C
H. Same as Point D
I. Once Preference List for Women is generated then we will print out Women Preference List
J. We will randomly generate a number again and if that number is not repeated then we will add into the new arraylist usedNumberForIterationList
K. GS Algorithm will start execution by first checking whether the number of men engaged are less than total number of men
L. We will use the random number generated in step J as a First Proposing Man and print out the name of the men
M. We have to find the preference list for that particular men and position with the women list and thats where we go to method titled "getPrefrenceIndex"
N. We match the women proposed by man with the women preference list and if it matches then we end the code block
   and return to assign that women to the men who proposed
O. Algorithm will continue for next men and Step N will run until man who proposed woman has already been engaged to another man
P. If the 2nd Men Proposed the same women who has already been engaged then "isCurrentMenPreferredMore" Method is triggered
Q. "isCurrentMenPreferredMore" Method will verify if the 2nd Men who proposed is 1st in her list, If yes then the CurrentMen will engaged to proposed women and 
   EngagedMen who is 1st proposing men will be set free
R. The loop will repeat until all the men are engaged and are not free
S. Once Step R is completed we will print how many proposals were taken
T. We will print the matched couples
U. GS Algorithm will start again but this time based on the random number generated and which is unused
V. At thr End of the algorithm, we need to print count of the number of proposals taken for n times execution of the algorithm

***********************************************************************************************************************************************************************

Methods:
1. prepareRandomPreferences - to generate random prefrences for men and women
2. notUniqueNumber - validation to trace everytime new number is being generating
3. getPrefrenceIndex - to get preference index of man for the woman input given to the metahod and vice-versa
4. isCurrentMenPrefrredMore - to check women preference in priority order
5. executeGSAlgorithm - to execute GS algorithm; To get stable matching pair.

***********************************************************************************************************************************************************************

Development Contribution:
Darshit 
1. prepareRandomPreferences
2. getPrefrenceIndex

Satish 
1. notUniqueNumber
2. isCurrentMenPrefrredMore

Common tasks with discussion:
Development: 
1. executeGSAlgorithm

Testing: 
1. We tested this program for random inputs and found everytime it is executing correctly.
2. We have tested scenarios with below inputs:
   A. Input = 100; Execution Time = 13 Seconds
   B. Input = 500; Execution Time = 4 Min 4 Seconds

Conclusion: 
1. Based on different tests we concluded that everytime matching couples are same and algorithm is absolutely correct.
2. Program execution is taking more time as we have to execute the algorithm for number of persons given with everytime different person proposing first.

***********************************************************************************************************************************************************************

Answers for the homework questions:
1. For the same instance of input, that is, each man and each woman's preference list is kept unchanged, 
   the Gale-Shapley Algorithm always produces the same output even when different man proposes first.

Justification:
As stated in algorithm, it will try to match each man with his preferred woman and also woman has a decision power to choose her partner based on her priority list.
After each proposal, at least one instance will occur where woman can check her preference list and able to decide whether this man is on her priority list or not and
according to that she can decide whether to accept the current proposal or not.
Eventhough algorithm we have implemented is men proposing, women will have rights to decide her partner based on her men preference list.

Men preferences: 
M1: W2 W1 W3 W4 W5 
M2: W3 W1 W5 W2 W4 
M3: W5 W2 W4 W3 W1 
M4: W1 W2 W5 W3 W4 
M5: W1 W2 W5 W4 W3 

Women preferences: 
W1: M4 M1 M5 M2 M3 
W2: M1 M3 M5 M2 M4 
W3: M4 M3 M1 M2 M5 
W4: M1 M4 M3 M2 M5 
W5: M2 M3 M4 M1 M5 

Stable Matching:
First Proposing Man is M2
M4 W1
M1 W2
M2 W3
M5 W4
M3 W5

Justification with proof of contradiction:
Let's assume that M2 <---> W4 is unstable pair.

Scenario 1: M2 will propose to his most prefered woman W3. W3 will accept it as she is not having other proposal yet.
	    Later at some point of time, let's assume that W3 will reject M2. And she got proposal from M3 and she accepts it as it stands in better preference position
	    than M2.
	    After execution of the algorithm, one woman and one man will be remaining which will make pair and it will be stable.
            So in this case no unstable pair i.e. M2 <---> W4.
Scenario 2: M2 never proposes to W3 since W3 stands in the top most priority of M2 and we are considering the scenario of men proposing.
	    So here also there is no unstable pair i.e. M2 <---> W4.

We can try this for different man proposing first.
First Proposing Man is M4.
Next man is M1, M2, M3, M5 respectively.

Scenario 1: Again M2 will propose W3 and before M2, M4 has proposed to W1, M1 has proposed to W2; so W3 will accept the proposal as she has not received any proposal.
	    Later W3 will not receive any proposal as all men will get their respective choice before W3. So only option will be left as M2 W3 which is not unstable.

Scenario 2: M2 never proposes to W3 since W3 stands in the top most priority of M2 and we are considering the scenario of men proposing.
	    So here also no unstable pair i.e. M2 <--> W4. Eventhough only W4 will be left in the group, one man will be there which will not be having any woman and 
            that woman can be paired up with the free man as no free man can be left. So in this case also no unstable pair occurs.

Conclusion: Based on above justification, we can conclude that Gale-Shapley algorithm produces no unstable pair and the same output will be generated(stable pairs) 
eventhough different man proposes first.

2. For the n times output, we have printed out the statistics that how many times each number of taken proposals occur.
Everytime same number of proposals will take place eventhough everytime different man proposes first.
Justification: Untill all stable pair occurs, proposals will be taking place. On top of that once man proposes to any woman and if he gets rejected he can not propose 
	       next time to the same woman and until woman gets her proposal and there is a free men.

***********************************************************************************************************************************************************************

Sample Output:
Please enter number of men or women: 
5
************************************************************
Men preferences: 
M1: W2 W1 W3 W4 W5 
M2: W3 W1 W5 W2 W4 
M3: W5 W2 W4 W3 W1 
M4: W1 W2 W5 W3 W4 
M5: W1 W2 W5 W4 W3 

Women preferences: 
W1: M4 M1 M5 M2 M3 
W2: M1 M3 M5 M2 M4 
W3: M4 M3 M1 M2 M5 
W4: M1 M4 M3 M2 M5 
W5: M2 M3 M4 M1 M5 
************************************************************
First Proposing Man is M1
M1 proposing W2
Next Proposing Man is M2
M2 proposing W3
Next Proposing Man is M3
M3 proposing W5
Next Proposing Man is M4
M4 proposing W1
Next Proposing Man is M5
M5 proposing W1
M5 rejected by W1
M5 proposing W2
M5 rejected by W2
M5 proposing W5
M5 rejected by W5
M5 proposing W4
Number of proposals are : 8
Matched couples are : 
M4 W1
M1 W2
M2 W3
M5 W4
M3 W5
Time taken for matching is 1591661 nanoseconds
************************************************************
First Proposing Man is M2
M2 proposing W3
Next Proposing Man is M1
M1 proposing W2
Next Proposing Man is M3
M3 proposing W5
Next Proposing Man is M4
M4 proposing W1
Next Proposing Man is M5
M5 proposing W1
M5 rejected by W1
M5 proposing W2
M5 rejected by W2
M5 proposing W5
M5 rejected by W5
M5 proposing W4
Number of proposals are : 8
Matched couples are : 
M4 W1
M1 W2
M2 W3
M5 W4
M3 W5
Time taken for matching is 1447562 nanoseconds
************************************************************
First Proposing Man is M4
M4 proposing W1
Next Proposing Man is M1
M1 proposing W2
Next Proposing Man is M2
M2 proposing W3
Next Proposing Man is M3
M3 proposing W5
Next Proposing Man is M5
M5 proposing W1
M5 rejected by W1
M5 proposing W2
M5 rejected by W2
M5 proposing W5
M5 rejected by W5
M5 proposing W4
Number of proposals are : 8
Matched couples are : 
M4 W1
M1 W2
M2 W3
M5 W4
M3 W5
Time taken for matching is 1349033 nanoseconds
************************************************************
First Proposing Man is M3
M3 proposing W5
Next Proposing Man is M1
M1 proposing W2
Next Proposing Man is M2
M2 proposing W3
Next Proposing Man is M4
M4 proposing W1
Next Proposing Man is M5
M5 proposing W1
M5 rejected by W1
M5 proposing W2
M5 rejected by W2
M5 proposing W5
M5 rejected by W5
M5 proposing W4
Number of proposals are : 8
Matched couples are : 
M4 W1
M1 W2
M2 W3
M5 W4
M3 W5
Time taken for matching is 1484510 nanoseconds
************************************************************
First Proposing Man is M5
M5 proposing W1
Next Proposing Man is M1
M1 proposing W2
Next Proposing Man is M2
M2 proposing W3
Next Proposing Man is M3
M3 proposing W5
Next Proposing Man is M4
M4 proposing W1
M5 rejected by W1
Next Proposing Man is M5
M5 proposing W2
M5 rejected by W2
M5 proposing W5
M5 rejected by W5
M5 proposing W4
Number of proposals are : 8
Matched couples are : 
M4 W1
M1 W2
M2 W3
M5 W4
M3 W5
Time taken for matching is 1406508 nanoseconds
************************************************************
Count of the number of iteration 8: 5

***********************************************************************************************************************************************************************

Thank you

***********************************************************************************************************************************************************************