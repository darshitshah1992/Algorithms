import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;
/**
 *
 * @author Darshit and Satish
 */
public class AlgorithmHW4DFS {

    private double[][] adjacencyMatrix = null;
    private int numberOfSensors = -1;
    private Stack<Integer> stack;
    ArrayList<String> sensorPositions = null;
    double transmissionRange = 0;
    static AlgorithmHW4DFS algorithmHW4;
    int numberOfDataGenerator = 0;
    int numberOfDataPacketsOfDG = 0;
    int numberOfDataPacketsOfStorageNode = 0;
    int numberOfDataStorageSensors = 0;
    ArrayList<Integer> noOfDataPackets = new ArrayList<Integer>();
    //
    double[] distances;
    private Set<Integer> settled;
    private Random random = new Random();
    int sizeOfEachDataPacket = 400;
    int dgNode = 0;
    int storageNode = 0;
    //int k=0;

    //Darshit
    DecimalFormat twoDForm = new DecimalFormat("#.##");
    static ArrayList<Vertex> vertexNodes =null;
    
    public AlgorithmHW4DFS() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter width of the sensor network: ");
        int width = scanner.nextInt();
        System.out.println("Please enter length of the sensor network: ");
        int length = scanner.nextInt();
        System.out.println("Please enter number of sensors in the network: ");
        int numberOfSensor = scanner.nextInt();
        System.out.println("Please enter transmission range for each sensor: ");
        transmissionRange = scanner.nextDouble();

        adjacencyMatrix = new double[numberOfSensor][numberOfSensor];
        numberOfSensors = numberOfSensor;
        stack = new Stack<Integer>();

        sensorPositions = generateSensorPositions(length, width, numberOfSensors);

        distances = new double[numberOfSensors + 1];
        settled = new HashSet<Integer>();

        System.out.println();
        System.out.println("Sensors are: ");
        int nodeCount = 1;
        for (String str : sensorPositions) {
            System.out.println(nodeCount + ". " + str);
            nodeCount++;
        }
        System.out.println();

        //Added by Darshit - Start
        for (int i = 0; i < numberOfSensors - 1; i++) {
            for (int j = i; j < numberOfSensors - 1; j++) {
                double distance = isDistanceOfTwoNodesLessThanTransmissionRange(sensorPositions.get(i), sensorPositions.get(j + 1));
                
                //System.out.println("Distance between "+ (i+1)+ " and "+ (j+2) +" is "+ distance);
                //System.out.println("Distance between "+ (j+2)+ " and "+ (i+1) +" is "+ distance);
                adjacencyMatrix[i][j + 1] = distance;
                adjacencyMatrix[j + 1][i] = distance;                                
            }            
        }
        
        vertexNodes = new ArrayList<Vertex>();
        Vertex vertex=null;        
        ArrayList<Edge> edgeList=null;
        for(int i=0;i<numberOfSensors;i++)
        {
            vertex = new Vertex(i+"");            
            edgeList = new ArrayList<Edge>();
            for(int j=0;j<numberOfSensors;j++)
            {
                if(adjacencyMatrix[i][j]<=transmissionRange)
                {
                    edgeList.add(new Edge(new Vertex(""+(j)),adjacencyMatrix[i][j]));
                }
//                if(adjacencyMatrix[j][i]>=transmissionRange)
//                {
//                    edgeList.add(new Edge(new Vertex(""+(i)),adjacencyMatrix[j][i]));
//                }
            }
            vertex.adjacencies=edgeList;
            vertexNodes.add(vertex);
        }
        
        //Added by Darshit - End
        System.out.println();

        if (executeDFSAlgorithm(0)) {
            System.out.println("The Sensor network is Connected.");
            System.out.println("Please enter number of data generator in the network: ");
            numberOfDataGenerator = scanner.nextInt();

            if (numberOfDataGenerator >= numberOfSensors) {
                System.out.println("There is no storage sensor available, please try again.");
                algorithmHW4 = new AlgorithmHW4DFS();
            } else {
                ArrayList<String> dataGeneratorList = new ArrayList<String>();

                for (int i = 0; i < numberOfDataGenerator; i++) {
                    int number = random.nextInt(numberOfSensors) + 1;
                    if (!dataGeneratorList.contains(String.valueOf(number))) {
                        dataGeneratorList.add(number + "");
                    } else {
                        i--;
                    }

                    //DG.add(sensorPositions.get(i));
                }

                System.out.println();
                System.out.println("Data generators are: ");
                for (String str : dataGeneratorList) {
                    System.out.println(str + ". " + sensorPositions.get(Integer.valueOf(str) - 1));
                }

                numberOfDataStorageSensors = numberOfSensors - numberOfDataGenerator;
                /*if(numberOfDataStorageSensors<=0)
            {
                System.out.println("Number of storage sensors are less than required, please try again!!!");
                algorithmHW4 = new AlgorithmHW4DFS();
            }
            else
            {            
                System.out.println("Please enter number of data packets each data generator in the network has: ");
                numberOfDataPacketsOfDG= scanner.nextInt();
                //arraylist = new ArrayList<Integer>(numberOfDataPacketsOfDG);
            }*/
                System.out.println("Please enter number of data packets each data generator sensors in the network has: ");
                numberOfDataPacketsOfDG = scanner.nextInt();

                //System.out.println("Storage Size of each Data Packet is equal to: " + sizeOfEachDataPacket);
                System.out.println("Please enter number of data packets each Storage Sensors in the network has: ");
                numberOfDataPacketsOfStorageNode = scanner.nextInt();

                int validation1 = numberOfDataGenerator * numberOfDataPacketsOfDG;
                //System.out.println(validation1);
                int validation2 = (numberOfDataStorageSensors * numberOfDataPacketsOfStorageNode);
                //System.out.println(validation2);

                if (validation1 > validation2) {
                    System.out.println("There is not enough storage in the network, Please try again.");
                    algorithmHW4 = new AlgorithmHW4DFS();
                } else {

                    System.out.println("Please enter a Source Data Generator Sensor");
                    dgNode = scanner.nextInt();
                    if (!dataGeneratorList.contains(String.valueOf(dgNode))) {
                        System.out.println("Node entered is not a valid Data Generator Sensor, Please try again.");
                        algorithmHW4 = new AlgorithmHW4DFS();
                    }

                    System.out.println("Please enter a Destination Storage Sensor");
                    storageNode = scanner.nextInt();

                    if (dataGeneratorList.contains(String.valueOf(storageNode))) {
                        System.out.println("Node entered is not a valid Destination Storage Sensor, Please try again.");
                        algorithmHW4 = new AlgorithmHW4DFS();
                    } else 
                    {
                        //
                            int startIndex=dgNode-1;
                            Vertex startVertex = vertexNodes.get(startIndex);
                            computePaths(startVertex); // run Dijkstra
                            
                            int endIndex=storageNode-1;
                            Vertex endVertex = vertexNodes.get(endIndex);
                            //System.out.println("Distance to " + storageNode + ": " + Double.valueOf(twoDForm.format(endVertex.minDistance)));
                            List<Integer> path = getShortestPathTo(endVertex);
                            System.out.println("minimum-energy data offloading path: " + path);
                            
                            System.out.println("Energy cost of offloading one data packet from DG Node "+ dgNode + " to Storage node "+ storageNode + " is: "+twoDForm.format(calculateRequiredEnergy(path))+" nJ.");
                                                       
                    }
                }
            }

        } else {
            System.out.println("The Sensor network is not Connected. Please try again");
            algorithmHW4 = new AlgorithmHW4DFS();
        }
    }

    private ArrayList<String> generateSensorPositions(int length, int width, int numberOfSensors) {
        ArrayList<String> sensorPositions = new ArrayList<String>();
        int count = 0;
        
        double numberLength = -1;
        double numberWidth = -1;

        Random random = new Random();
        while (count < numberOfSensors) {
            numberLength = Double.valueOf(twoDForm.format(random.nextFloat() * length));
            numberWidth = Double.valueOf(twoDForm.format(random.nextFloat() * width));

            sensorPositions.add(numberLength + "," + numberWidth);
            count++;
        }
        return sensorPositions;
    }

    private double isDistanceOfTwoNodesLessThanTransmissionRange(String nodeOne, String nodeTwo) {
        String[] nodeOneStr = nodeOne.split(",");
        double nodeOneXValue = Double.parseDouble(nodeOneStr[0]);
        double nodeOneYValue = Double.parseDouble(nodeOneStr[1]);

        String[] nodeTwoStr = nodeTwo.split(",");
        double nodeTwoXValue = Double.parseDouble(nodeTwoStr[0]);
        double nodeTwoYValue = Double.parseDouble(nodeTwoStr[1]);

        double distanceX = nodeOneXValue - nodeTwoXValue;
        double distanceY = nodeOneYValue - nodeTwoYValue;
        distanceX = distanceX * distanceX;
        distanceY = distanceY * distanceY;
        //double distance = Double.valueOf(Math.sqrt(distanceX + distanceY));

//        if(distance<=transmissionRange)
//            return true;        
//        else
        return Double.parseDouble(twoDForm.format(Math.sqrt(distanceX + distanceY)));
    }

    private boolean executeDFSAlgorithm(int startingSensor) {
        int[] explored = new int[numberOfSensors];
        int i, currentSensor;

        explored[startingSensor] = 1;
        stack.push(startingSensor);
        while (!stack.isEmpty()) {
            currentSensor = stack.pop();
            i = 0;
            while (i < numberOfSensors) {
                if (adjacencyMatrix[currentSensor][i] <= transmissionRange && explored[i] == 0) {
                    stack.push(i);
                    explored[i] = 1;
                }
                i++;
            }
        }

        int count = 0;
        for (int j = 0; j < numberOfSensors; j++) {
            if (explored[j] == 1 && j != startingSensor) {
                count++;
            }
        }

        if (count == numberOfSensors - 1) {
            return true;
        } else {
            return false;
        }
    }
    
    public static void main(String[] args) {
        algorithmHW4 = new AlgorithmHW4DFS();
    }
    
    public static void computePaths(Vertex source)
    {
        source.minDistance = 0.;
        PriorityQueue<Vertex> vertexQueue = new PriorityQueue<Vertex>();
        vertexQueue.add(source);

        while (!vertexQueue.isEmpty()) 
        {
            Vertex u = vertexQueue.poll();

            // Visit each edge exiting u
            if(u!=null && u.adjacencies!=null && !u.adjacencies.isEmpty())
            {
                for (Edge e : u.adjacencies)
                {
                    Vertex v =  vertexNodes.get(Integer.parseInt(e.target.name));
                    double weight = e.weight;
                    double distanceThroughU = u.minDistance + weight;
                    if (distanceThroughU < v.minDistance) 
                    {
                        vertexQueue.remove(v);

                        v.minDistance = distanceThroughU ;
                        v.previous = u;
                        vertexQueue.add(v);
                    }
                }
            }
        }
    }

    public static List<Integer> getShortestPathTo(Vertex target)
    {
        List<Integer> path = new ArrayList<Integer>();
        for (Vertex vertex = target; vertex != null; vertex = vertex.previous)
            path.add(Integer.parseInt(vertex.name)+1);

        Collections.reverse(path);
        return path;
    }
    
    private double calculateRequiredEnergy(List<Integer> path)
    {
        double totalEnergy=-1;
        int k=3200;
        int Eamp=100;
        int Eelec=100000;
        double transmissionEnergy=0;
        double receivingEnergy=0;
        double intermediateEnergy=0;
        for(int i=0;i<path.size();i++)
        {
            if(i==0)
            {
                transmissionEnergy= (Eelec * k) + (Eamp * k * adjacencyMatrix[path.get(i)-1][path.get(i+1)-1] * adjacencyMatrix[path.get(i)-1][path.get(i+1)-1]);
            }
            else if(i==path.size()-1)
            {
                receivingEnergy=Eelec * k;
            }
            else
            {
                intermediateEnergy +=  (Eelec * k) + (Eamp * k * adjacencyMatrix[path.get(i)-1][path.get(i+1)-1] * adjacencyMatrix[path.get(i)-1][path.get(i+1)-1]);
            }
        }
        totalEnergy = Double.valueOf(twoDForm.format(transmissionEnergy + receivingEnergy + intermediateEnergy));
        long number=1000000000l;
        return (totalEnergy/number);
    }   
   
}

class Vertex implements Comparable<Vertex>
{
    public final String name;
    public ArrayList<Edge> adjacencies;
    public double minDistance = Double.POSITIVE_INFINITY;
    public Vertex previous;
    public Vertex(String argName) 
    { 
        name = argName; 
    }
    public String toString() 
    { 
        return name; 
    }
    public int compareTo(Vertex other)
    {
        return Double.compare(minDistance, other.minDistance);
    }
    
    
}

class Edge
{
    public final Vertex target;
    public final double weight;
    public Edge(Vertex argTarget, double argWeight)
    { 
        target = argTarget; 
        weight = argWeight; 
    }
}