import java.text.DecimalFormat;
import java.util.*;
/**
 *
 * @author Darshit and Satish
 */
public class AlgorithmHW5DFS {

    private double[][] adjacencyMatrix = null;
    private int numberOfSensors = -1;
    private Stack<Integer> stack;
    ArrayList<String> sensorPositions = null;
    double transmissionRange = 0;
    static AlgorithmHW5DFS algorithmHW5;
    int numberOfDataGenerator = 0;
    int numberOfDataPacketsOfDG = 0;
    int numberOfDataPacketsOfStorageNode = 0;
    int numberOfDataStorageSensors = 0;
    ArrayList<Integer> noOfDataPackets = new ArrayList<Integer>();
    double[] distances;
    private Set<Integer> settled;
    private Random random = new Random();
    int sizeOfEachDataPacket = 400;
    int dgNode = 0;
    int storageNode = 0;
    public static final int MAX_VALUE = 999;
    private int visited[];
    private double spanningTree[][];
    private List<Edge> edges;
    DecimalFormat twoDForm = new DecimalFormat("#.##");
    private double spanning_tree[][];
    Edge edge[];
    
    public AlgorithmHW5DFS() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter width of the sensor network: ");
        int width = scanner.nextInt();
        System.out.println("Please enter length of the sensor network: ");
        int length = scanner.nextInt();
        System.out.println("Please enter number of sensors in the network: ");
        int numberOfSensor = scanner.nextInt();
        System.out.println("Please enter transmission range for each sensor: ");
        transmissionRange = scanner.nextDouble();

        adjacencyMatrix = new double[numberOfSensor][numberOfSensor];
        numberOfSensors = numberOfSensor;
        stack = new Stack<Integer>();
        spanningTree = new double[numberOfSensors+1][numberOfSensors+1];

        sensorPositions = generateSensorPositions(length, width, numberOfSensors);

        distances = new double[numberOfSensors + 1];
        settled = new HashSet<Integer>();
        visited = new int[numberOfSensors+1];
        System.out.println();
        System.out.println("Sensors are: ");
        int nodeCount = 1;
        for (String str : sensorPositions) {
            System.out.println(nodeCount + ". " + str);
            nodeCount++;
        }
        System.out.println();

        edges = new ArrayList<Edge>();
        Edge edge = null;
        for (int i = 0; i < numberOfSensors - 1; i++) {
            for (int j = i; j < numberOfSensors - 1; j++) {
                double distance = isDistanceOfTwoNodesLessThanTransmissionRange(sensorPositions.get(i), sensorPositions.get(j + 1));

                if(distance>0)
                {
                    edge = new Edge();
                    edge.src=i;
                    edge.dest=j+1;
                    edge.weight=distance;
                    edges.add(edge);
                    adjacencyMatrix[i][j + 1] = distance;
                    edge = new Edge();
                    edge.src=j+1;
                    edge.dest=i;
                    edge.weight=distance;
                    //edges.add(edge);
                    adjacencyMatrix[j + 1][i] = distance;
                }
            }
        }

        System.out.println();
        
        if (executeDFSAlgorithm(0)) {
            System.out.println("The Sensor network is Connected.");
            System.out.println("Please enter number of data generator in the network: ");
            numberOfDataGenerator = scanner.nextInt();

            if (numberOfDataGenerator >= numberOfSensors) {
                System.out.println("There is no storage sensor available, please try again.");
                algorithmHW5 = new AlgorithmHW5DFS();
            } else {
                ArrayList<String> dataGeneratorList = new ArrayList<String>();

                for (int i = 0; i < numberOfDataGenerator; i++) {
                    int number = random.nextInt(numberOfSensors) + 1;
                    if (!dataGeneratorList.contains(String.valueOf(number))) {
                        dataGeneratorList.add(number + "");
                    } else {
                        i--;
                    }
                }

                System.out.println();
                System.out.println("Data generators are: ");
                for (String str : dataGeneratorList) {
                    System.out.println(str + ". " + sensorPositions.get(Integer.valueOf(str) - 1));
                }

                numberOfDataStorageSensors = numberOfSensors - numberOfDataGenerator;
				System.out.println();
                System.out.println("Please enter number of data packets each data generator sensors in the network has: ");
                numberOfDataPacketsOfDG = scanner.nextInt();

                //System.out.println("Storage Size of each Data Packet is equal to: " + sizeOfEachDataPacket);
				System.out.println();
                System.out.println("Please enter number of data packets each Storage Sensors in the network has: ");
                numberOfDataPacketsOfStorageNode = scanner.nextInt();

                int validation1 = numberOfDataGenerator * numberOfDataPacketsOfDG;
                int validation2 = (numberOfDataStorageSensors * numberOfDataPacketsOfStorageNode);

                if (validation1 > validation2) {
                    System.out.println("There is not enough storage in the network, Please try again.");
                    algorithmHW5 = new AlgorithmHW5DFS();
                } else {

                        kruskalMST();
                }
            }

        } else {
            System.out.println("The Sensor network is not Connected. Please try again");
            algorithmHW5 = new AlgorithmHW5DFS();
        }
    }

    private ArrayList<String> generateSensorPositions(int length, int width, int numberOfSensors) {
        ArrayList<String> sensorPositions = new ArrayList<String>();
        int count = 0;

        double numberLength = -1;
        double numberWidth = -1;

        Random random = new Random();
        while (count < numberOfSensors) {
            numberLength = Double.valueOf(twoDForm.format(random.nextFloat() * length));
            numberWidth = Double.valueOf(twoDForm.format(random.nextFloat() * width));

            sensorPositions.add(numberLength + "," + numberWidth);
            count++;
        }
        return sensorPositions;
    }

    private double isDistanceOfTwoNodesLessThanTransmissionRange(String nodeOne, String nodeTwo) {
        String[] nodeOneStr = nodeOne.split(",");
        double nodeOneXValue = Double.parseDouble(nodeOneStr[0]);
        double nodeOneYValue = Double.parseDouble(nodeOneStr[1]);

        String[] nodeTwoStr = nodeTwo.split(",");
        double nodeTwoXValue = Double.parseDouble(nodeTwoStr[0]);
        double nodeTwoYValue = Double.parseDouble(nodeTwoStr[1]);

        double distanceX = nodeOneXValue - nodeTwoXValue;
        double distanceY = nodeOneYValue - nodeTwoYValue;
        distanceX = distanceX * distanceX;
        distanceY = distanceY * distanceY;
        double distance = Double.parseDouble(twoDForm.format(Double.valueOf(Math.sqrt(distanceX + distanceY))));

        if(distance<=transmissionRange) 
        {
           return distance;
        }
        else 
        {
           return -1;
        }
    }

    private boolean executeDFSAlgorithm(int startingSensor) {
        int[] explored = new int[numberOfSensors];
        int i, currentSensor;

        explored[startingSensor] = 1;
        stack.push(startingSensor);
        while (!stack.isEmpty()) {
            currentSensor = stack.pop();
            i = 0;
            while (i < numberOfSensors) {
                if (adjacencyMatrix[currentSensor][i]>0 && adjacencyMatrix[currentSensor][i] <= transmissionRange && explored[i] == 0) {
                    stack.push(i);
                    explored[i] = 1;
                }
                i++;
            }
        }

        int count = 0;
        for (int j = 0; j < numberOfSensors; j++) {
            if (explored[j] == 1 && j != startingSensor) {
                count++;
            }
        }

        if (count == numberOfSensors - 1) {
            return true;
        } else {
            return false;
        }
    }

    public static void main(String[] args) {
        algorithmHW5 = new AlgorithmHW5DFS();

    }

    private double calculateRequiredEnergy(double distance)
    {
        double totalEnergy=-1;
        int k=3200;
        int Eamp=100;
        int Eelec=100000;
        double transmissionEnergy=0;
        double receivingEnergy=0;

        if(distance>0)
        {
            transmissionEnergy = (Eelec * k) + (Eamp * k * distance * distance);
            receivingEnergy = Eelec * k;
        }

        totalEnergy = Double.valueOf(twoDForm.format(transmissionEnergy + receivingEnergy ))/1000000000l;
        if (totalEnergy == 0) {
            return -1;
        }
        else 
        {
            return totalEnergy;
        }
    }

    class Edge
    {
        int src, dest;
        double weight;
 
        public int compareTo(Edge compareEdge)
        {            
            return Double.valueOf(this.weight-compareEdge.weight).intValue();
        }       
    };
 
    class subset
    {
        int parent, rank;
    }; 
    
    int find(subset subsets[], int i)
    {
        if (subsets[i].parent != i)
            subsets[i].parent = find(subsets, subsets[i].parent);
 
        return subsets[i].parent;
    }
 
    void Union(subset subsets[], int x, int y)
    {
        int xroot = find(subsets, x);
        int yroot = find(subsets, y);
 
        if (subsets[xroot].rank < subsets[yroot].rank)
            subsets[xroot].parent = yroot;
        else if (subsets[xroot].rank > subsets[yroot].rank)
            subsets[yroot].parent = xroot;
 
        else
        {
            subsets[yroot].parent = xroot;
            subsets[xroot].rank++;
        }
    }
 
    void kruskalMST()
    {
        int V = numberOfSensors;
        int E = edges.size();
        
        Edge result[] = new Edge[numberOfSensors-1];
        int e = 0;  
        int i = 0;  
        for (i=0; i<numberOfSensors-1; i++)
            result[i] = new Edge();
 
        Collections.sort(edges, new Comparator<Edge>() 
        {
            @Override
            public int compare(Edge c1, Edge c2) 
            {
                return Double.compare(c1.weight, c2.weight);
            }
        });
        
        subset subsets[] = new subset[V];
        for(i=0; i<V; i++)
            subsets[i]=new subset();
 
        for (int v = 0; v < V; v++)
        {
            subsets[v].parent = v;
            subsets[v].rank = 0;
        }
 
        i = 0;
 
        while (e < V - 1 && i<edges.size())
        {
            Edge next_edge = new Edge();
            next_edge = edges.get(i++);
 
            int x = find(subsets, next_edge.src);
            int y = find(subsets, next_edge.dest);
 
            if (x != y)
            {
                result[e++] = next_edge;
                Union(subsets, x, y);
            }
        }
 
        ArrayList<String> arrayListNodes = new ArrayList<String>();
        double totalSpanningTreeEnergy = 0;
        System.out.println();
		System.out.println("Following are the edges in " + 
                                     "the constructed MST");
        
        for (i = 0; i < e; i++)
        {
            System.out.println((i+1)+". "+result[i].src+" -- " + 
                   result[i].dest+" with distance " + result[i].weight);
            arrayListNodes.add(sensorPositions.get(result[i].src));
            arrayListNodes.add(sensorPositions.get(result[i].dest));        
            totalSpanningTreeEnergy += calculateRequiredEnergy(result[i].weight);
        }
        
		System.out.println();
        System.out.println("Total Spanning Tree Energy is: "+ Double.valueOf(twoDForm.format(totalSpanningTreeEnergy)) + " nJ");        
    }        
}
