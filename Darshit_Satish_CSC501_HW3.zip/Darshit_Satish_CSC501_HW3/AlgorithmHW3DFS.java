import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author Darshit and Satish
 */
public class AlgorithmHW3DFS{

    private int[][] adjacencyMatrix =null;
    private int numberOfSensors=-1;
    private Stack<Integer> stack;
    boolean isConnected=false;
    ArrayList<String> sensorPositions=null;
    ArrayList<Integer> connectedSensorsList=new ArrayList<Integer>();
    ArrayList<Integer> avoidDuplicateSensorsKey = new ArrayList<Integer>();
    int countOfConnectedComponents=0;
    HashMap hashMap = new HashMap();
    
    public AlgorithmHW3DFS(int length, int width,int numberOfSensor,double transmissionRange)
    {
        adjacencyMatrix = new int[numberOfSensor][numberOfSensor];
        numberOfSensors = numberOfSensor;
        stack = new Stack<Integer>();
        
        sensorPositions=generateSensorPositions(length, width, numberOfSensors);
        
        System.out.println();
        System.out.println("Sensors are: ");
        int nodeCount=1;
        for(String str : sensorPositions)
        {
            System.out.println(nodeCount+". "+str);
            nodeCount++;
        }
        System.out.println();
        
        for(int i=0;i<numberOfSensors-1;i++)
        {
            ArrayList<Integer> connectedSensors = new ArrayList<Integer>();
            for(int j=i;j<numberOfSensors-1;j++)
            {
                boolean flag = isDistanceOfTwoNodesLessThanTransmissionRange(sensorPositions.get(i),sensorPositions.get(j+1),transmissionRange);
                if(flag)
                {  
                    connectedSensors.add(j+1);
                    adjacencyMatrix[i][j+1]=1;
                    adjacencyMatrix[j+1][i]=1;
                }
            }
        }
        
        System.out.println();
         
        for(int i=0;i<numberOfSensors;i++)
        {
            for(int j=0;j<numberOfSensors;j++)
            {
                if(numberOfSensors>9)
                {
                    if(j<=9)
                    {
                        System.out.print(adjacencyMatrix[i][j]+"  ");
                    }
                    else
                    {
                        System.out.print(adjacencyMatrix[i][j]+"  ");
                    }
                }
                else
                {
                    System.out.print(adjacencyMatrix[i][j]+" ");
                }
            }
            System.out.println();
        }
        
        System.out.println();
                
        long startTime = System.nanoTime();
        int startingSensor=0;
        while(!isConnected && startingSensor<numberOfSensors)
        {
            executeDFSAlgorithm(startingSensor);
            startingSensor++;
        }
        
        if(isConnected)
        {
            System.out.println("The Sensor network is Connected.");
        }
        else
        {
            System.out.println("The Sensor network is not Connected.");
            
            System.out.println();
            
            System.out.println("Number of Connected Components are: "+ countOfConnectedComponents);
            for(int i=1;i<=numberOfSensors;i++)
            {
                if(hashMap.containsKey(i))
                {
                    ArrayList<Integer> sensorList = (ArrayList) hashMap.get(i);
                    
                    System.out.print("Connected component "+ i +" is: ");
                    
                    for(int j=0;j<sensorList.size();j++)
                    {
                        if(j==sensorList.size()-1)
                            System.out.print(sensorList.get(j)+".");
                        else
                            System.out.print(sensorList.get(j)+", ");
                    }
                                        
                    System.out.println();
                }
            }
        }        
        
        System.out.println("Execution time for DFS algorithm is: "+ (System.nanoTime()-startTime)+ " nanoseconds");
                
    }
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Please enter width of the sensor network: ");
        int width=scanner.nextInt();
        System.out.println("Please enter length of the sensor network: ");
        int length=scanner.nextInt();
        System.out.println("Please enter number of sensors in the network: ");
        int numberOfSensor=scanner.nextInt();
        System.out.println("Please enter transmission range for each sensor: ");
        double transmissionRange=scanner.nextDouble();
        AlgorithmHW3DFS algorithmHW3 = new AlgorithmHW3DFS(length,width,numberOfSensor,transmissionRange);
    }
    
    private ArrayList<String> generateSensorPositions(int length, int width, int numberOfSensors)
    {
        ArrayList<String> sensorPositions = new ArrayList<String>();
        int count=0;
        DecimalFormat twoDForm = new DecimalFormat("#.##");        
        double numberLength=-1;
        double numberWidth=-1;        
        
        Random random = new Random();
        while(count<numberOfSensors)
        {
            numberLength = Double.valueOf(twoDForm.format(random.nextFloat() * length));
            numberWidth = Double.valueOf(twoDForm.format(random.nextFloat() * width));
            
            sensorPositions.add(numberLength+","+numberWidth);
            count++;
        }
        return sensorPositions;
    }
    
    private boolean isDistanceOfTwoNodesLessThanTransmissionRange(String nodeOne, String nodeTwo, double transmissionRange)
    {
        String[] nodeOneStr= nodeOne.split(",");
        double nodeOneXValue = Double.parseDouble(nodeOneStr[0]);
        double nodeOneYValue = Double.parseDouble(nodeOneStr[1]);
         
        String[] nodeTwoStr= nodeTwo.split(",");
        double nodeTwoXValue = Double.parseDouble(nodeTwoStr[0]);
        double nodeTwoYValue = Double.parseDouble(nodeTwoStr[1]);
        
        double distanceX = nodeOneXValue-nodeTwoXValue;
        double distanceY = nodeOneYValue-nodeTwoYValue;
        distanceX = distanceX * distanceX;
        distanceY = distanceY * distanceY;
        double distance = Math.sqrt(distanceX + distanceY);
        
//        System.out.println(distance);
//        System.out.println(Math.floor(distance));
        if(distance<=transmissionRange)
            return true;        
        else
            return false;
    }
    
    private void executeDFSAlgorithm(int startingSensor)
    {
        int[] explored = new int[numberOfSensors];
        int i, currentSensor;
        
        explored[startingSensor] = 1;
        stack.push(startingSensor);
        while (!stack.isEmpty())
        {
            currentSensor = stack.pop();
            i = 0;
            while (i < numberOfSensors)
            {
                if (adjacencyMatrix[currentSensor][i] == 1 && explored[i] == 0)
                {
                    stack.push(i);
                    explored[i] = 1;
                }
                i++;
            }
        }

//        System.out.print("The sensor " + (startingSensor+1) + " is connected to: ");
        
        int count = 0;
        connectedSensorsList = new ArrayList<Integer>();
        for (int j = 0; j < numberOfSensors; j++)
        {
            if (explored[j] == 1 && j!=startingSensor)
            {
//                System.out.print((j+1) + " ");
                count++;
                connectedSensorsList.add(j+1);
            }
        }
        
        if(count==0)
        {
            //System.out.print(" -");
        }
        else
        {
            if(!connectedSensorsList.isEmpty() && !avoidDuplicateSensorsKey.contains(Integer.valueOf(startingSensor+1)))
            {
                connectedSensorsList.add(startingSensor+1);
                countOfConnectedComponents++;
                hashMap.put(countOfConnectedComponents, connectedSensorsList);                
            }
            avoidDuplicateSensorsKey.addAll(connectedSensorsList);
        }
        
        
        
        if (count == numberOfSensors-1)
        {
            isConnected=true;
        }
        
//        System.out.println();
    }      
}
